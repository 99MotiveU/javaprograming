package week05;

public class task07 {

	public static void main(String[] args) {
		//1에서 20까지 숫자 중에서 6의 배수를 제외하여 출력하는 프로그램을 작성
		int i = 0;
		for(i=1;i<=20;i++) {
			if(i%6!=0) {
				System.out.println("1에서 20까지의 숫자 중에서 6의 배수를 제외한 수는 : " +i);
			}
		}
	}

}
