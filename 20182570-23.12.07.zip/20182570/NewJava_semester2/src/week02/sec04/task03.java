package week02.sec04;

public class task03 {

	public static void main(String[] args) {
		//int
		
		int var1 = -12854636;
		int var2 = -24845;
		int var3 = 1578106;
		int var4 = 4561;
		
		System.out.println(var1+var2);
		System.out.println(var2-var3);
		System.out.println(var2*var3);
		System.out.println(var3/var4);

	}

}
