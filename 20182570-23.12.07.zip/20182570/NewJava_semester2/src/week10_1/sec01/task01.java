package week10_1.sec01;

public class task01 {
	//곱하기
	//리턴값이 없는 메소드 선언
	void powerOn() {
		System.out.println("전원을 켭니다");
	}
	
	//리턴값이 없는 메소드 선언
	void powerOff() {
		System.out.println("전원을 끕니다.");
	}
	
	//호출 시 두 정수 값을 전달 받고, 호출한 곳으로 결과값 double을 리턴하는 메소드 선언
	double mul(int x, int y) {
		int result = x * y;
		return result; //리턴값 지정
	}
}
