package week05;

public class task12 {

	public static void main(String[] args) {
		// +-----+-----+-----+-----+-----+를 출력

	}

}
