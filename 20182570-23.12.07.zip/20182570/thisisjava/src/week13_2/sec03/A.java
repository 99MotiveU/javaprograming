package week13_2.sec03;

public interface A {
	
}
