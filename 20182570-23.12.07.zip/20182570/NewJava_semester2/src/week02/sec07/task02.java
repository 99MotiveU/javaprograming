package week02.sec07;

import java.util.Scanner;

public class task02 {

	public static void main(String[] args) {
		// 원의 둘레, 넓이, 부피 값 입력받아 계산
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("r 값 입력");
		String strR = scanner.nextLine();
		int r = Integer.parseInt(strR);
		
		double l = 3.14*2*r;
		double s = 3.14*r*r;
		double v = 4/3*r*r*r;
		System.out.println("원의 둘레는 : " + l);
		System.out.println("원의 넓이는 : " + s);
		System.out.println("원의 부피는 : " + v);
	}

}
