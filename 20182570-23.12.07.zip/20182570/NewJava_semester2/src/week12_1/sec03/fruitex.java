package week12_1.sec03;

public class fruitex {
	public void method() {
		Apple a = new Apple();
		a.field = "먹는다";
		a.method();
	}
}
