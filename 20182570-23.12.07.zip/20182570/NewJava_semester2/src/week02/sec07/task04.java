package week02.sec07;

import java.util.Scanner;

public class task04 {

	public static void main(String[] args) {
		// 복리와 단리 이자값을 입력 받아서 계산
		Scanner scanner = new Scanner(System.in);

		System.out.print("원금 입력 : ");
		String strPV = scanner.nextLine();
		int PV = Integer.parseInt(strPV);
		
		System.out.print("이자율 입력(%) : ");
		String strR = scanner.nextLine();
		int r = Integer.parseInt(strR);
		
		System.out.print("기간 입력(개월) : ");
		String strN = scanner.nextLine();
		int n = Integer.parseInt(strN);
		
		double FV1 = PV*(1+(0.01*r)*n);
		double FV2 = PV*(Math.pow((1+(0.01*r)),n));
		
		System.out.println("복리의 경우 원금+이자는 " + FV1 + "원입니다.");
		System.out.print("복리의 경우 원금+이자는 " + FV2 + "원입니다.");
	}

}
