package week09_1.pet;

public class PetExample {

	public static void main(String[] args) {
		Pet p1 = new Pet();
		System.out.println("p1 변수가 pet 객체를 참조합니다.");

		Pet p2 = new Pet();
		System.out.println("p2 변수가 또다른 pet 객체를 참조합니다.");
	}

}
