package week07.sec02;

import java.util.Scanner;

public class task04 {

	public static void main(String[] args) {
		// 처음 수와 마지막수를 입력 받아서 그 수들 사이의 숫자 중 7로 끝나는 숫자만 출력하는 프로그램
		Scanner scanner = new Scanner(System.in);
		System.out.println("처음 수를 입력하세요 ");
		int a = scanner.nextInt();
		System.out.println("마지막 수를 입력하세요");
		int b = scanner.nextInt();
		
		int i=1;
		for(i=a;i<b+1;i++) {
			
			if(i%10!=6) {
				continue;
			}
			System.out.println(i);
		}
		
	}
	
}
