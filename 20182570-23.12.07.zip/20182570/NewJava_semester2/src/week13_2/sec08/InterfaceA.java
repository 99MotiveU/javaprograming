package week13_2.sec08;

public sealed interface InterfaceA permits InterfaceB {
	void methodA();
}
