package week06.sec01;

public class task03 {

	public static void main(String[] args) {
		// 7단을 출력.
		int i =1;
		int mul = 1;
		while(i<9) {
			i++;
			mul*=i;
			System.out.println("7 * "+ i + " = " + 7*i);
		}
	}

}
