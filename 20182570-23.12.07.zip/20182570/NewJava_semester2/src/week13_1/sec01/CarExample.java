package week13_1.sec01;

public class CarExample {

	public static void main(String[] args) {
		Car car;
		
		car = new KIA();
		car.model();
		car = new Hyundai();
		car.model();
	}

}
