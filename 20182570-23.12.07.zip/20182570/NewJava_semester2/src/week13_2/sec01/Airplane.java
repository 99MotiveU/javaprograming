package week13_2.sec01;

public interface Airplane {
	void fly();
	void land();
}
