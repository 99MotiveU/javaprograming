package week11_2.sec04;

public class Calculator {
	public double areaCircle(double r) {
		System.out.println("Calculaor 객체의 areaCircle() 실행");
		return 3.141569 * r * r; 
	}
}
