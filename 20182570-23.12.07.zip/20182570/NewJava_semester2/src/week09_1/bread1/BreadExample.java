package week09_1.bread1;

public class BreadExample {

	public static void main(String[] args) {
		Bread myBread = new Bread();
		
		System.out.println("빵 종류 : " + myBread.name);
		System.out.println("빵 갯수 : " + myBread.count);
		System.out.println("칼로리 : " + myBread.cal);
		System.out.println("가격 : " + myBread.price);


	}

}
