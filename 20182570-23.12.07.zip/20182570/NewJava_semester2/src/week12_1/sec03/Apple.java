package week12_1.sec03;

public class Apple {
	protected String field;
	
	protected Apple() {
	}
	protected void method() {
		
	}
}
