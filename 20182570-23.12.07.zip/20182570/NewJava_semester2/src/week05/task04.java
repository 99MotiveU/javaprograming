package week05;

import java.util.Scanner;

public class task04 {

	public static void main(String[] args) {
		//원하는 구구단을 입력 받아서 출력
		Scanner scan =new Scanner(System.in);
		System.out.println("구구단 단수를 입력하세요");
		int t = scan.nextInt();
		int i;
		for(i=1; i<=9; i++) {
			for(i=1; i<=9; i++) {
				System.out.println(t+"*"+i+"="+t*i);
			}
		}
	}

}
