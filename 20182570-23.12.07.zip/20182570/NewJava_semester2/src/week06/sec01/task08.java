package week06.sec01;

import java.util.Scanner;

public class task08 {

	public static void main(String[] args) {
		// 1.예금 2.출금 3.잔고 4.종료 로 화면에 보이고 선택하며 각 예금액이나 추금액을 입력 받아서 금액을 보이는 프로그램 작성(switch문 사용) + 설명문 (얼마입금, 잔고)		public static void main(String[] args) {
		boolean run = true;
		int balance = 0;
		Scanner scanner = new Scanner(System.in);
		while(run) {
			System.out.println("-------------------------------------");
			System.out.println("1.예금 | 2.출금 | 3.잔고 | 4.종료");
			System.out.println("-------------------------------------");
			System.out.print("선택> ");
		int menuNum = Integer.parseInt(scanner.nextLine());
		switch(menuNum) {
		case 1:
			System.out.print("예금액 : ");
			balance += Integer.parseInt(scanner.nextLine());
			System.out.println("계좌 잔액 :" + balance);
			break;
		case 2:
			System.out.print("출금액 : ");
			balance -= Integer.parseInt(scanner.nextLine());
			System.out.println("계좌 잔액 :" + balance);
			break;
		case 3:
			System.out.print("잔고> ");
			System.out.println("계좌 잔액 : "+balance);
			break;
		case 4:
			run = false;
			break;
			}
			System.out.println();
		}
		System.out.println("프로그램 종료");
		
	}

}
