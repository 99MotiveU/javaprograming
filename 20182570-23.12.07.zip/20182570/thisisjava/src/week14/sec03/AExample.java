package week14.sec03;

public class AExample {

	public static void main(String[] args) {
		//B 객체 생성
		A.B b = new A.B();

	}

}
