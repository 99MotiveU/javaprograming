package week13_2.sec04;

public interface Vehicle {
	void fly();
}
