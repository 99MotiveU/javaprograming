package week06.sec02;

public class WhileTest01 {

	public static void main(String[] args) {
		// 1부터 10까지 출력
		//while문 : 조건이 맞지 않으면 아예 실행하이 않는다.
		//int i =11;
		int i = 1;
		while(i<=10) {
			System.out.print(i+ " ");
			i++;
		}
		
		System.out.println();
		//do-while문: 조건식에 맞지 않아도 무조건 한 번 실행하기 때문에 11이 출력 된다
		//int j=11;
		int j =1;
		do {
			System.out.print(j+" ");
			j++;
		}while(j<=10);
	}

}
