package week08.sec01;

public class NullPointerExceptionExample {

	public static void main(String[] args) {
		int[] intArray = null;
		int Array[0] = 10; //NullPointerException
		
		String str = null;
		System.out.println("총문자 수 : " + str.length());//NullPointerException
		
		//오류 해결 위해선 값을 넣어야함
	}

}
