package week07.sec02;

public class task05 {

	public static void main(String[] args) {
		// 100이하의 자연수 중에 5의 배수이자 7의 배수인 정수를 전부 출력하고, 그 수를 세어보는 프로그램 작성
		int i =1;
		int t =0;
		for(i=1;i<100;i++) {
			if(i%5!=0 && i%7 !=0) {
				continue;
			}
			System.out.println("100이하의 자연수 중에 5의 배수이자 7의 배수인 수 : "+i);
		++t;
		}
		System.out.println("개수 : "+ t);
	}

}
