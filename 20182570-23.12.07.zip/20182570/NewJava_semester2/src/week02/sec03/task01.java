package week02.sec03;

public class task01 {

	public static void main(String[] args) {
		int pen = 1000;
		int pencil = 500;
		System.out.println("펜은 " + pen + "원 "+ "연필은 " + pencil + "원 입니다.");
		
		int ti = 3500;
		int exch = 1500;
		System.out.println("떡볶이는 " + ti + "원 " + "치즈추가는 " + exch + "원 입니다.");

	}

}
