package week09_2.sec04;

public class SnackExample {

	public static void main(String[] args) {
		Snack snack1 = new Snack("비스킷");
		System.out.println("snack1.type : " + snack1.type);
		System.out.println();
		
		Snack snack2 = new Snack("비스킷","참 ing");
		System.out.println("snack2.type : " + snack2.type);
		System.out.println("snack2.name : " + snack2.name);
		System.out.println();
		
		Snack snack3 = new Snack("비스킷","참 ing",8);
		System.out.println("snack3.type : " + snack3.type);
		System.out.println("snack3.wp : " + snack3.name);
		System.out.println("snack3.count : " + snack3.count);
		System.out.println();
		
		Snack snack4 = new Snack("비스킷","참 ing",8,2500);
		System.out.println("snack4.type : " + snack4.type);
		System.out.println("snack4.wp : " + snack4.name);
		System.out.println("snack4.count : " + snack4.count);
		System.out.println("snack4.price : " + snack4.price);		
		

	}

}
