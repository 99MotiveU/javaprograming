package week13_2.sec06;

public interface Vehicle {
	void run();
}
