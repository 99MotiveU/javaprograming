package week09_1.water;

public class Water {
	String brand = "삼다수";
	String bottle = "페트병";
	int ml = 500;
	int price = 1000;
}
