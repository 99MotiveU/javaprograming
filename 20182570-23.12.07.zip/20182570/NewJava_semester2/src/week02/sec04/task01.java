package week02.sec04;

public class task01 {

	public static void main(String[] args) {
		//byte
		
		byte var1 = -126;
		byte var2 = -25;
		byte var3 = 5;
		byte var4 = 25;
		
		System.out.println(var1+var2);
		System.out.println(var2-var3);
		System.out.println(var2*var3);
		System.out.println(var4/var3);
	}

}
