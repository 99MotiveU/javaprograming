package week13_2.sec06;

public class DriverExample {

	public static void main(String[] args) {
		Driver driver = new Driver();
		
		Airplane ap = new Airplane();
		Person p = new Person();
		
		driver.drive(ap);
		driver.drive(p);
	}

}
