package week09_1.sec01;

public class SportsCar {
}

class Tire{
	

}
