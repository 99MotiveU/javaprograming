package week05;

public class task05 {

	public static void main(String[] args) {
		//1에서 10까지 숫자를 곱하는 프로그램
		int i;
		int mul =1;
		for(i=1; i<=10; i++) {
			mul*=i;
			System.out.println("1에서 10까지의 수를 곱하면 : "+mul);
		}
		System.out.println("1에서 10까지의 수를 곱하면 : "+mul);
	}

}
