package week13_2.sec02;

public class InterfaceCImpl implements InterfaceC{
	public void methodA() {
		System.out.println("InterfaceImpl-methodA() 실행");
	}
	public void methodB() {
		System.out.println("InterfaceImpl-methodB() 실행");
	}
	public void methodC() {
		System.out.println("InterfaceImpl-methodC() 실행");
	}
}
