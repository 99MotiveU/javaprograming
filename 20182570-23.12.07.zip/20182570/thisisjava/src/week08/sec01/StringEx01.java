package week08.sec01;

public class StringEx01 {

	public static void main(String[] args) {
		
		String target = "Welcome to java World";
		
		System.out.println(target.concat(" and workspace"));
		System.out.println(target.substring(11));
		System.out.println(target.substring(11,15));
		System.out.println(target.replace("o","O"));
		System.out.println(target.replace("java","C"));
		System.out.println(target.toLowerCase());
		System.out.println(target.toUpperCase());	
	}

}
