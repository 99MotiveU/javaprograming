package week07.sec02;

public class task03 {

	public static void main(String[] args) {
		// 1에서 73까지의 숫자 중 6으로 끝나는 숫자만 출력하는 프로그램을 구성하시오.
		int i = 1;
		for(i=1;i<74;i++) {
			if(i%10!=6) {
				continue;
			}
			System.out.println("1에서 73까지의 숫자 중 6으로 끝나는 숫자 : "+i);
		}
	}

}
