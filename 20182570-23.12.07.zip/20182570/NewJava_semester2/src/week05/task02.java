package week05;

import java.util.Scanner;

public class task02 {

	public static void main(String[] args) {
		//반복수를 입력받아서 합을 출력
		Scanner scanner = new Scanner(System.in);
		System.out.print("반복 횟수를 입력하세요 : ");
		int t = scanner.nextInt();
		int i;
		int sum = 0;
		for (i=1; i<=t; i++) {
			sum+=i;
		//system.out.println(sum);
		}
		System.out.println("반복한 수들의 합 : "+sum);
		scanner.close();
	}
	

}
