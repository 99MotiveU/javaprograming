package week08.sec02;

public enum week {
	MONDAY,
	TUESDAY,
	WEDNSDAY,
	THURSDAY,
	FRIDAY,
	SATURDAY,
	SUNDAY
}
