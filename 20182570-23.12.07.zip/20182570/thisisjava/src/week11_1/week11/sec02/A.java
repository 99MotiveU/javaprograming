package week11.sec02;

public class A {

}
