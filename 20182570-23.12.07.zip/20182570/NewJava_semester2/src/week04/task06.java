package week04;

import java.util.Scanner;

public class task06 {

	public static void main(String[] args) {
		// 월, 일을 따로 입력 받아 별자리를 출력하는 프로그램을 작성하라(switch,if-else 모두 사용)
		Scanner scan = new Scanner(System.in);
		System.out.println("월을 입력하세요.");
		int month=scan.nextInt();
		System.out.println("일을 입력하세요.(1,3,5,7,8,10,12월은 31일일까지, 4,6,9,11월은 30일까지, 2월은 29일까지 만 입력)");
		int d=scan.nextInt();
		
		switch(month) {
		case 1 -> {
			if(d<32&d>20) {
				System.out.println("염소자리 입니다.");
			}
			else {
				System.out.println("궁수자리 입니다.");
			}
		}
		case 2 -> {
			if(30>d&d>16) {
				System.out.println("물병자리 입니다.");
			}
			else {
				System.out.println("염소자리 입니다.");
			}
		}
		case 3 -> {
			if(11>d&d<31) {
				System.out.println("물고기자리 입니다.");
			}
			else {
				System.out.println("물병자리 입니다.");
			}
		}
		case 4 -> {
			if(18<d&d>31) {
				System.out.println("양자리 입니다.");
			}
			else {
				System.out.println("물고기자리 입니다.");
			}
		}
		case 5 -> {
			if(13<d&d<31) {
				System.out.println("황소자리 입니다.");
			}
			else {
				System.out.println("양자리 입니다.");
			}
		}
		case 6 -> {
			if(d<23) {
				System.out.println("황소자리 입니다.");
			}
			else {
				System.out.println("쌍둥이자리 입니다.");
			}
		}
		case 7 ->{
			if(d>22) {
				System.out.println("쌍둥이자리 입니다.");
			}
			else {
				System.out.println("게자리 입니다.");
			}
		}
		case 8 ->{
			if(d<12) {
				System.out.println("게자리 입니다.");
			}
			else {
				System.out.println("사자자리 입니다.");
			}
		}
		case 9 ->{
			if(d<17) {
				System.out.println("사자자리 입니다.");
			}
			else {
				System.out.println("처녀자리 입니다.");
			}
		}
		case 10 ->{
			if(d<31) {
				System.out.println("처녀자리 입니다.");
			}
			else {
				System.out.println("천칭자리 입니다.");
			}
		}
		case 11 ->{
			if(d<24) {
				System.out.println("천칭자리 입니다.");
			}
			else if(d>23&d<30) {
				System.out.println("전갈자리 입니다.");
			}
			else {
				System.out.println("뱀주인자리 입니다.");
			}
		}
		case 12 ->{
			if(d<18) {
				System.out.println("뱀주인자리 입니다.");
			}
			else {
				System.out.println("궁수자리 입니다.");
			}
		}
		default -> {
			System.out.println("존재하지 않는 달입니다.");
		}
		
		};

		
		scan.close();
	}

}
