package week13_2.sec07;

public class InstanceofExample {

	public static void main(String[] args) {
		Airplane ap = new Airplane();
		Person p = new Person();
		
		ride(ap);
		System.out.println();
		ride(p);
	}
	public static void ride(Vehicle vehicle) {
		if(vehicle instanceof Airplane ap) {
			ap.checkFare();
		}
		vehicle.run();
	}


}
