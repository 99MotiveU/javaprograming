package week13_2.sec05;

public interface Airplane {
	void fly();
}
