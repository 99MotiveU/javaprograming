package week11.sec02;
import week11.sec02.*;
public class C {
	B b;
}
