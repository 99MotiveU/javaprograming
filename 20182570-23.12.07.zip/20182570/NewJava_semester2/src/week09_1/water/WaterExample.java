package week09_1.water;

public class WaterExample {

	public static void main(String[] args) {
		Water myWater = new Water();
		
		System.out.println("브랜드 :" + myWater.brand);
		System.out.println("분리수거 타입 : " + myWater.bottle);
		System.out.println("용량 : " + myWater.ml);
		System.out.println("가격 : " + myWater.price);
	}

}
