package week08;

import java.util.Scanner;

public class task04 {

	public static void main(String[] args) {
		// 사용자로부터 이름을 입력받을 때, 성과 이름을 공백으로 분리시켜서 입력받기
		Scanner scanner = new Scanner(System.in);
		System.out.println("성함이 어떻게 되세요?");
		String str = scanner.nextLine();
		String[] str1 =str.split(",");
		System.out.println("성 : " + str1[0] + "    ");
		System.out.println("이름 : "+ str1[1]);
		
	}

}
