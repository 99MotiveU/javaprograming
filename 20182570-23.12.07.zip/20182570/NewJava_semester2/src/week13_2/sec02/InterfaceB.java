package week13_2.sec02;

public interface InterfaceB {
	void methodB();
}
