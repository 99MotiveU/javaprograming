package week06.sec01;

import java.util.Scanner;

public class task06 {

	public static void main(String[] args) {
		// 무한 루프를 돌리고 두수를 입력 받고 사칙연산 중 선택하여 계산하는 프로그램 작성
		Scanner scanner = new Scanner(System.in);
		System.out.println("두 수 입력");
		int i = scanner.nextInt();
		int t = scanner.nextInt();
		
		System.out.println("사칙연산 선택 : 1.덧셈 2.뺄셈 3.곱셈 4.나눗셈");
		int a = scanner.nextInt();
		int sum=1;
		int sub=1;
		int mul=1;
		int div=1;
		while(a==1) {
			sum=i+t;
			System.out.println("두 수의 합 : " + sum);
		}
		while(a==2) {
			sub=i-t;
			System.out.println("두 수의 차 : " + sub);
		}
		while(a==3) {
			sub=i*t;
			System.out.println("두 수의 곱 : " + sub);
		}
		while(a==4) {
			sub=i/t;
			System.out.println("두 수 나누기 : " + sub);
		}
	}

}
