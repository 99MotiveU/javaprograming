package week08;

public class task03 {

	public static void main(String[] args) {
		//"나는 정말로 행복해"의 무자열을 생서하고 빈칸을 구분하여 출력
		String lying = "나는, 정말, 행복해";
		String[] lying1 =lying.split(",");
		System.out.println("주어 : " + lying1[0] + "    ");
		System.out.println("부사 : "+ lying1[1]);
		System.out.println("서술어 : "+ lying1[2]);
	}

}
