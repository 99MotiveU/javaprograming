package week05;

public class task06 {

	public static void main(String[] args) {
		//1에서 20까지의 숫자 중에서 7과 3의 배수를 출력하는 프로그램
		
		for(int i =1;i<=20;i++) {
			//if(i%3==0 | i%7==0) {
				//System.out.println("1에서 20까지의 수 중 3의 배수와 7의 배수는 :" +i);
			if(i%7 == 0) {
				System.out.println("1에서 20까지의 수 중 7의 배수 : "+ i);
			}
			if(i%3==0) {
				System.out.println("1에서 20까지의 수 중 3의 배수 : "+ i);
			}
		}

	}

}
