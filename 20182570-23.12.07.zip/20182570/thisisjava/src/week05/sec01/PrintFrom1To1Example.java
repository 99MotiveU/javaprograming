package week05.sec01;

public class PrintFrom1To1Example {

	public static void main(String[] args) {
		//int i;
		for(int i=1; i<=10; i++) {
			System.out.print(i + " ");
		}
		//System.out.print(i);
	}
	//변수 체크!!!
}
