package week12_1.sec10;

public class Parent {
	//필드 선언
	public String field1;
	
	//메소드 선언
	public void method1() {
		System.out.println("Parent-method1()");
	}
	
	//메소드 선언
	public void mehtod2() {
		System.out.println("Parent-method2()");
	}
}
