package week09_1.sec02;

public class Student {

}
