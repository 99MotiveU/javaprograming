package week09_1.person1;

public class Person {
	String name = "유동기";
	int age = 25;
	String sex = "male";
	int weight = 90;
	int height = 177;
}
