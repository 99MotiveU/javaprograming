package week11.sec03;

public class B {
	A a1 = new A(true);
	A a2 = new A(1);
	
}
