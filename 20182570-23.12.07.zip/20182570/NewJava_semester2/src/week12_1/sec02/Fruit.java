package week12_1.sec02;

public class Fruit {
	//필드 선언
	public int count;
	
	//메소드 선언
	public void abandon() {
		count -=1;
		System.out.println("썩은 과일을 버린다");
	}
	
	//final 메소드
	public final void eat() {
		System.out.println("과일을 먹는다");
		count = 0;
	}
}
