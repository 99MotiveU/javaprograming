package week05.sec01;

public class ex01 {

	public static void main(String[] args) {
		for(int i = 0, j=10; i<=5 &&j<=10; i++,j--)
		{
			System.out.println("i = "+i+" j = "+j);
		}

	}

}
