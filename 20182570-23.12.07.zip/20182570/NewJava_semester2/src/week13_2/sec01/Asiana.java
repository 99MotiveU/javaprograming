package week13_2.sec01;

public class Asiana implements Airplane,Searchable {
	@Override
	public void fly() {
		System.out.println("아시아나 항공 비행기가 이륙합니다.");
	}
	@Override
	public void land() {
		System.out.println("아시아나 항공 비행기가 착륙합니다.");
	}
	@Override
	public void search(String url) {
		System.out.println(url + "을 검색합니다.");
	}
}
