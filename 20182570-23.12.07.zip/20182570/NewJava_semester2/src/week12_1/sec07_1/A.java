package week12_1.sec07_1;

public class A {
	protected String field;
	protected A() {
	}
	protected void method() {
		
	}
}
