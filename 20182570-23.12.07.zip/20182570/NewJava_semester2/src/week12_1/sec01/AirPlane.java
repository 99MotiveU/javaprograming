package week12_1.sec01;

public class AirPlane {
	//필드 선언
	public int speed;
	
	//메소드 선언
	public void speedUp() {
		speed +=1;
	}
	//final 메소드
	public final void fly() {
		System.out.println("이륙합니다.");
		speed = 800;
	}
}
