package week02.sec07;

import java.util.Scanner;

public class task01 {

	public static void main(String[] args) {
		//사칙연산 값 입력 받아 계산
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("x 값 입력");
		String strX = scanner.nextLine();
		int x = Integer.parseInt(strX);
		
		
		System.out.print("y 값 입력");
		String strY = scanner.nextLine();
		int y = Integer.parseInt(strY);
		
		int result1 = x+y;
		int result2 = x-y;
		int result3 = x*y;
		int result4 = x/y;
		System.out.println("x + y : " + result1);
		System.out.println("x - y : " + result2);
		System.out.println("x * y : " + result3);
		System.out.println("x / y : " + result4);
	}

}
