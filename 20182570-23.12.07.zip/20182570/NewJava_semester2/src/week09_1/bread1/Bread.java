package week09_1.bread1;

public class Bread {
		String name = "바게트";
		int count = 5;
		String cal = "개당 210";
		int price = 3000;


}
