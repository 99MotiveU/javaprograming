package week12_1.sec09;

public class Parent {
	public void method1() {
		System.out.println("Parent-mehtod1()");
	}
	
	public void method2() {
		System.out.println("Parent-method2()");
	}
}
