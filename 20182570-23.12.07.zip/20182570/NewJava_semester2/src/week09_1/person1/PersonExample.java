package week09_1.person1;

public class PersonExample {

	public static void main(String[] args) {
		Person myPerson = new Person();
		
		System.out.println("이름 : " + myPerson.name);
		System.out.println("나이 : " + myPerson.age);
		System.out.println("성별 : " + myPerson.sex);
		System.out.println("몸무게 : " + myPerson.weight);
		System.out.println("키 : " + myPerson.height);


	}

}
