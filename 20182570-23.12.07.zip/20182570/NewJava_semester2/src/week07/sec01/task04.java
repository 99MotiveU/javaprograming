package week07.sec01;

public class task04 {

	public static void main(String[] args) {
		// 4x+5y=60을 만족하는 x,와 y를 구하고 해를 구하면 멈추시오
		int x;
		int y;
		for(x=0; x<=15;x++) {
			for(y=0; y<=12; y++) {
	
				}
			}
		}
	}

