package week11.sec01;
import week11.sec01.hankook.SnowTire;
import week11.sec01.kumho.AllSeasonTire;
public class hyundai {
	week11.sec01.hankook.Tire tire1 = new
	week11.sec01.hankook.Tire();
	week11.sec01.kumho.Tire tire2 = new week11.sec01.kumho.Tire();
	SnowTire tire3 = new SnowTire();
	AllSeasonTire tire4 = new AllSeasonTire();
}
