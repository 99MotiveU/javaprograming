package week13_2.sec01;

public class MultiInterfaceImplExample {

	public static void main(String[] args) {
		Airplane ap = new Asiana();
		ap.fly();
		ap.land();
		Searchable searchable = new Asiana();
		searchable.search("https://www.naver.com");

	}

}
