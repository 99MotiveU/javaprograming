package week02.sec04;

public class task04 {

	public static void main(String[] args) {
		//long
		
		long var1 = -1245432136;
		long var2 = -2457451;
		long var3 = 3614561;
		long var4 = 19751;
		
		System.out.println(var1+var3);
		System.out.println(var2-var4);
		System.out.println(var1*var2);
		System.out.println(var3/var4);

	}

}
