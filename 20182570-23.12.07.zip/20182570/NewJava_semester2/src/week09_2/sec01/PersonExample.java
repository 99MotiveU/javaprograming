package week09_2.sec01;

public class PersonExample {

	public static void main(String[] args) {		
		Person person1 = new Person("유동기");
		System.out.println("person1.name : " + person1.name);
		System.out.println();
		
		Person person2 = new Person("유동기",25);
		System.out.println("person2.name : " + person2.name);
		System.out.println("person2.age : " + person2.age);
		System.out.println();
		
		Person person3 = new Person("유동기",25,"male");
		System.out.println("person3.name : " + person3.name);
		System.out.println("person3.age : " + person3.age);
		System.out.println("person3.sex : " + person3.sex);
		System.out.println();
		
		Person person4 = new Person("유동기",25,"male",90);
		System.out.println("person4.name : " + person4.name);
		System.out.println("person4.age : " + person4.age);
		System.out.println("person4.sex : " + person4.sex);
		System.out.println("person4.weight : " + person4.weight);
		System.out.println();
		
		Person person5 = new Person("유동기",25,"male",90);
		System.out.println("person5.name : " + person5.name);
		System.out.println("person5.age : " + person5.age);
		System.out.println("person5.sex : " + person5.sex);
		System.out.println("person5.weight : " + person5.weight);	
		System.out.println("person5.height : " + person5.height);
	}

}
