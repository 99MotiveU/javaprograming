package week13_1.sec02;

public interface Fruit {
	public void fruit();
}
