package week13_2.sec01;

public interface Searchable {
	void search(String url);
}
