package week02.sec05;

public class task02 {

	public static void main(String[] args) {
		//원의 면적과 부피를 계산하는 프로그램을 작성하세요.
		int r = 5;
		double s = 3.14*r*r;
		double v = 4/3*r*r*r; 
		
		System.out.println("반지름이 5일때 원의 면적은 " + s + "원의 부피는 " + v + "입니다.");
	}

}
