package week09_1.house;

public class HouseExample {

	public static void main(String[] args) {
		House h1 = new House();
		System.out.println("h1 변수가 house 객체를 참조합니다.");
		
		House h2 = new House();
		System.out.println("h2 변수가 또 다른 house 객체를 참조합니다.");
	}

}
