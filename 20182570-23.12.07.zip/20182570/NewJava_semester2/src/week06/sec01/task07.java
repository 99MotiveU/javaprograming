package week06.sec01;

import java.util.Scanner;

public class task07 {

	public static void main(String[] args) {
		// 종료때까지 수를 입력 받아서 총합과 평균을 계산 하시오.
		Scanner scanner = new Scanner(System.in);
		boolean a= true;
		int sum =1;
		while(a){
		System.out.println("수 입력");
		int x = scanner.nextInt();
		sum += x;
		
		System.out.println("프로그램을 종료 하시겠습니까? 0");
		int t = scanner.nextInt();
		if(t==0) {
			a=false;
		}
		}
		
	
		
		System.out.println(sum);
		System.out.println("프로그램 종료");
	}
}
