package week05.sec01;

public class FloatCounterExample {

	public static void main(String[] args) {
		for(float x=0.1f; x<=1.0f; x+=0.1f) {
			System.out.println(x);
		}
		//초기화식에서 부동 소수점을 쓰는 float 타입을 사용하지 않도록 주의
	}

}
