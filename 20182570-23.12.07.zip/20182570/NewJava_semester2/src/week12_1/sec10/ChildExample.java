package week12_1.sec10;

public class ChildExample {
	public static void main(String[] args) {
		Child child = new Child();
		
		Parent parent = child;
		
		parent.method1();
		parent.method2();
		//parnet.method3(); 호출 불가능
	}
}
