package week13_2.sec06;

public interface Vehicle {
	//추상 메소드
	void run();
}
