package week09_2.sec01;

public class Person {
	String name;
	int age;
	String sex;
	int weight;
	int height;

	Person(String name){
		this(name, 25, "남성", 90, 177);
	}
	Person(String name, int age){
		this(name, age,"남성", 90, 177);
	}
	Person(String name, int age, String sex){
		this(name, age, sex, 90, 177);
	}
	Person(String name, int age, String sex, int weight){
		this(name, age, sex, weight, 177);
	}
	Person(String name, int age, String sex, int weight, int height){
		this.name = name;
		this.age = age;
		this.sex = sex;
		this.weight =weight;
		this.height = height;
	}
}
