package week07.sec01;

public class BreakOutterExample {

	public static void main(String[] args) throws Exception {
		//증찹 반복문에서 바깥 반복문 종료를 원할때 -> 이름 명명, 그 후 break 이름
		Outter: for(char upper='A'; upper<='Z'; upper++) {
			for(char lower='a'; lower<='z'; lower++) {
				System.out.println(upper + "-" + lower);
				if(lower=='g') {
					break Outter;
				}
			}
		}
		System.out.println("프로그램 실행 종료");
	}

}
