package week06.sec02;

public class task03 {

	public static void main(String[] args) {
		// 7x^2+4y의 값을 구하는 프로그램 작성

	}

}
