package week13_2.sec06;

public class Driver {
	void drive( Vehicle vehicle) {
		vehicle.run();
	}
}
