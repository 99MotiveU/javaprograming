package week09_1.bread;

public class BreadExample {

	public static void main(String[] args) {
		Bread b1 = new Bread();
		System.out.println("b1 변수가 Student 객체를 참조합니다");
		
		Bread b2 = new Bread();
		System.out.println("b2 변수가 또 다른 Student 객체를 참조합니다");

	}

}
