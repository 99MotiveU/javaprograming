package week09_1.house1;

public class House {
	String name = "원룸";
	int roomcount = 0;
	int toiletcount = 1;
	String ground = "마당 없음";

}
