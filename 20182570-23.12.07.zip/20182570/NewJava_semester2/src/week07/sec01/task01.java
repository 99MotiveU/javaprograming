package week07.sec01;

public class task01 {

	public static void main(String[] args) {
		// 1부터 숫자를 더하여 100이 넘는 순간의 그 숫자와 합을 출력하는 코드 작성.
		int num = 1;
		int q =0;
		while(true) {
			q = q + num;
			//System.out.println(sum)
			++num;
			if(q==100) {
			System.out.println("100이 넘는 순간 그 숫자의 합 :"+ q );
			System.out.println("숫자 : "+num);
			break;
			
			}
		
		}
	}

}
