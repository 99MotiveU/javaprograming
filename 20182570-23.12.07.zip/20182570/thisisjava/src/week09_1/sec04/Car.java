package week09_1.sec04;

public class Car {
	String company = "현대자동차";
	String model = "그랜저";
	String color = "검정";
	int maxSpeed = 350;
	int speed;
	public static void main(String[] args) {
		System.out.println("현재 속도 : ");
	}
}
