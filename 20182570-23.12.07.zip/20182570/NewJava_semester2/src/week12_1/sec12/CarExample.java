package week12_1.sec12;

public class CarExample {
	public stgatic void main(String[] args) {
	Car myCar = new Car();
	
	myCar.tire = new Tire();
	myCar.run();
	
	myCar.tire = new HankookTire();
	myCar.run();
	
	myCar.tire = new KumhoTire();
	myCar.run();
	}
}