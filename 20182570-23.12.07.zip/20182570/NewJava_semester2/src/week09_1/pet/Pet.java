package week09_1.pet;

public class Pet {

}
