package week12_1.sec04;

public class VeryImportantPeron extends Member {

}
