package week10_1.sec04;


public class task04Ex {

	public static void main(String[] args) {
		task04 food = new task04();
		
		
		food.setfood(5);
		
		
		if(food.isLeftfood()) {
			System.out.println("먹습니다");
			
			food.eat();
		}
		System.out.println("재료 소진으로 break타임 입니다.");

	}

}
