package week13_2.sec07;

public interface Vehicle {
	void run();
}
