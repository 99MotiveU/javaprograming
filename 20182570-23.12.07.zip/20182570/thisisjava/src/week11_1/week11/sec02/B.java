package week11.sec02;

public class B {
	A a;
}
