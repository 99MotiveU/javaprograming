package week09_1.pet1;

import week09_1.house1.House;

public class PetExample {

	public static void main(String[] args) {
		Pet myPet = new Pet();
		
		System.out.println("종 : " + myPet.type);
		System.out.println("이름 : " + myPet.name);
		System.out.println("나이 : " + myPet.age);
		System.out.println("몸무게 : " + myPet.weight);
		System.out.println("키 : " + myPet.height);

	}

}
