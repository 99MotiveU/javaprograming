package week09_2.sec02;

public class PetExample {

	public static void main(String[] args) {
		Pet pet1 = new Pet("말티즈");
		System.out.println("pet1.type : " + pet1.type);
		System.out.println();
		
		Pet pet2 = new Pet("말티즈","유마음");
		System.out.println("pet2.type : " + pet2.type);
		System.out.println("pet2.name : " + pet2.name);
		System.out.println();
		
		Pet pet3 = new Pet("말티즈","유마음",8);
		System.out.println("pet3.type : " + pet3.type);
		System.out.println("pet3.name : " + pet3.name);
		System.out.println("pet3.age : " + pet3.age);
		System.out.println();
		
		Pet pet4 = new Pet("말티즈","유마음",8,3);
		System.out.println("pet4.type : " + pet4.type);
		System.out.println("pet4.name : " + pet4.name);
		System.out.println("pet4.age : " + pet4.age);
		System.out.println("pet4.weight : " + pet4.weight);
		System.out.println();
		
		Pet pet5 = new Pet("말티즈","유마음",8,3,40);
		System.out.println("pet5.type : " + pet5.type);
		System.out.println("pet5.name : " + pet5.name);
		System.out.println("pet5.age : " + pet5.age);
		System.out.println("pet5.weight : " + pet5.weight);
		System.out.println("pet5.height : " + pet5.height);

	}

}
