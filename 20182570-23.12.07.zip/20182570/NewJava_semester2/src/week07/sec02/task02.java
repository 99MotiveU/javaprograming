package week07.sec02;

public class task02 {

	public static void main(String[] args) {
		// 1부터 100까지 중 홀수만 더하는 프로그램 작성
		int sum =0;
		int i=1;
		for(i=1;i<101;i++) {
			
			if(i%2==1) {
				sum = sum+i;
				continue;
			}
			System.out.println("홀수만 더하면 : "+ sum);	
		}
		System.out.println();
		System.out.println("최종 : "+ sum);
	}

}
