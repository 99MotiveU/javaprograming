package week13_1.sec01;

public class KIA implements Car {
	@Override
	public void model() {
		System.out.println("KIA 자동차 입니다.");
	}
}
