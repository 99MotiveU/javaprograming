package week13_1.sec01;

public interface RemoteControl {
	//public 추상 메소드
	public void turnOn();
}
