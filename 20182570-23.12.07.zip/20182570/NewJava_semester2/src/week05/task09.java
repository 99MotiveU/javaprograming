package week05;

public class task09 {

	public static void main(String[] args) {
		// 1에서 73까지의 숫자 중 6으로 끝나는 숫자만 출력하는 프로그램
		int i =0;
		for(i=1;i<=73;i++) {
			if(i%10==6) {
				System.out.println("1에서 73까지의 숫자 중 6으로 끝나는 숫자는 : "+i);
			}
		}
	}

}
