package week10_1.sec06;

public class task06 {
	// 매개변수 길이 결정 없이 입력을 받아서 합계와 평균을 구하시오.
	int sum(int...values) {
		int sum =0;
		for(int i = 0; i<values.length; i++) {
			sum+=values[i];
		}
		return sum;
	}
	double ave(int...values) {
		double ave = 1;
		int sum=0;
		for(int i =0; i<values.length; i++) {
			sum+=values[i];
		}
		ave = sum/values.length;
		return ave;
	}
}
