package week05;

import java.util.Scanner;

public class task11 {

	public static void main(String[] args) {
		// n의 팩토리얼이 출력되게 만드세요. 팩토리얼은 1부터 n까지의 숫자를 차례대로 곱한 값입니다
		//결과 출력 : 1*2*3*4*.....*n=값
		Scanner scanner = new Scanner(System.in);
		System.out.println("n의 값을 입력 : ");
		int n = scanner.nextInt();
		
			
	}

}
