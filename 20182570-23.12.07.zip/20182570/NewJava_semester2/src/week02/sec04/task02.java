package week02.sec04;

public class task02 {
	public static void main(String[] args) {
	//short
		
	short var1 = -1236;
	short var2 = -245;
	short var3 = 361;
	short var4 = 19;
	
	System.out.println(var1+var2);
	System.out.println(var2-var3);
	System.out.println(var2*var3);
	System.out.println(var3/var4);
	}
}
