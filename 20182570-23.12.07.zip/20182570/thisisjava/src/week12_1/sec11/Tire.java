package week12_1.sec11;

public class Tire {
	public void roll() {
		System.out.println("회전합니다.");
	}
}
