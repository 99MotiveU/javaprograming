package week13_1.sec02;

public class FruitExample {

	public static void main(String[] args) {
		Fruit fruits;
		
		fruits = new Apple();
		fruits.fruit();
		fruits = new Orange();
		fruits.fruit();

	}

}
