package week06.sec02;

public class task05 {

	public static void main(String[] args) {
		// 1~10까지의 수를 do-while문을 사용하여 곱하기

	}

}
