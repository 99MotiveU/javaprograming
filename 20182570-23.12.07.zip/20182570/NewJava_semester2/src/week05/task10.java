package week05;

import java.util.Scanner;

public class task10 {

	public static void main(String[] args) {
		// 처음 수와 마지막수를 입력 받아서 그 수들 사이의 숫자 중 7으로 끝나는 숫자만 출력하는 프로그램을 구성
		Scanner scanner = new Scanner(System.in);
		System.out.println("처음 수 입력 : ");
		int t = scanner.nextInt();
		System.out.println("마지막 수 입력 : ");
		int f = scanner.nextInt();
		
		for(t=t;t<=f;t++) {
			if(t%10 ==7) {
				System.out.println("7으로 끝나는 숫자는 :" + t);
			}
		}
		
	}
	

}
