package week05;

public class task03 {

	public static void main(String[] args) {
		//7단을 출력
		int i;
		int mul = 1;
		for(i=1; i<=9; i++) {
			mul*=i;
			System.out.println("7단 : " + 7*i);
		}
		
	}

}
