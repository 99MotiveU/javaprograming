package week13_2.sec02;

public interface InterfaceC extends InterfaceA, InterfaceB{
	//추상 메소드
	void methodC();
}
