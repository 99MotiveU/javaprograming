package week11.sec01.hankook;

public class Tire {

}
