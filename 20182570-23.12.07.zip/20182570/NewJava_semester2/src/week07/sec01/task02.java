package week07.sec01;

public class task02 {

	public static void main(String[] args) {
		// 5의 배수이자 7의 배수인 가장 작은 수
		int a = 1;
		while(true) {
			a++;
			if(a%5==0&&a%7==0) {
				System.out.println("5의 배수이자 7의 배수인 가장 작은 수 :" + a);
				break;
			}
		}

	}

}
