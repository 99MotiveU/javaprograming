package week04;

import java.util.Scanner;

public class task04 {

	public static void main(String[] args) {
		// 10보다 작은 경우, 20보다 작은 경우, 30보다 작은 경우의 수를 입력 받아서 확인하는 코드 작성 (switch case이용)
		Scanner scan = new Scanner(System.in);
		System.out.println("수를 입력하세요:");
		int num=scan.nextInt();
		
		switch(num) {
			case 1,2,3,4,5,6,7,8,9 -> {
				System.out.println("10보다 작은 수 입니다.");
			}
			case 10,11,12,13,14,15,16,17,18,19 -> {
				System.out.println("20보다 작은 수 입니다.");
			}
			case 20,21,22,23,24,25,26,27,28,29 -> {
				System.out.println("30보다 작은 수 입니다.");
			}
			default -> {
				System.out.println("설정된 범위의 수가 아닙니다.");

			}
		
		};
		scan.close();
	}

}
