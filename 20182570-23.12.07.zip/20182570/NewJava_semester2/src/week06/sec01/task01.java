package week06.sec01;

public class task01 {

	public static void main(String[] args) {
		//hello java 10번 반복 출력
		int i =1;
		while(i<=10) {
			System.out.print("hello java ");
			i++;

		}
	}
}
