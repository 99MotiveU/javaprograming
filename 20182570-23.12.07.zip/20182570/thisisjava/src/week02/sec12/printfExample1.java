package week02.sec12;

public class printfExample1 {

	public static void main(String[] args) {
		int a =3;
		char b='A';
		String c= "Code";
		
		System.out.printf("a = %d %n",a);
		System.out.printf("b = %c %n",b);
		System.out.printf("c = %s %n",c);
	}

}
