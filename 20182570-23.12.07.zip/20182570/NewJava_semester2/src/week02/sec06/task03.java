package week02.sec06;

public class task03 {

	public static void main(String[] args) {
		// 소수점이 있는 변수를 3개 선언하고 소수 첫째,둘째,셋째 자리가 나오도록하고 세 수의 합을 10의 자리에 소수점 3자리로 나오게 하라
		double a = 10.12;
		double b = 7.34;
		double c = 4.78;
		double x = a*b*c;
		double y = a+b+c;
		System.out.printf("a*b*c : %.3f\n",x);
		System.out.printf("a+b+c : %.3f",y);
	}

}
