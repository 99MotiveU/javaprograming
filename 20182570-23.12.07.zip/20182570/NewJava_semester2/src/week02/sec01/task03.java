package week02.sec01;

public class task03 {

	public static void main(String[] args) {
		System.out.println("나는 행복해");

	}

}
