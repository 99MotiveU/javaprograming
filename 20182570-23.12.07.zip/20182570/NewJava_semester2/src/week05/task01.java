package week05;

public class task01 {

	public static void main(String[] args) {
		//hello java 10번 반복 출력
		for(int i =1; i<=10; i++) {
			System.out.println("hello java");
		}

	}

}
