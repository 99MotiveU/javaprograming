package week02.sec04;

public class task05 {

	public static void main(String[] args) {
		//char
		
		char var1 = 'F';
		char var2 = 122;
		char var3 = '유';
		char var4 = 56478;
		
		System.out.println(var3+var4);
		System.out.println(var2-var3);
		System.out.println(var4*var3);
		System.out.println(var2/var1);

	}

}
