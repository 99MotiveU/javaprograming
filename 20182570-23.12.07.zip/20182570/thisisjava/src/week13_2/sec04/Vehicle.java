package week13_2.sec04;

public interface Vehicle {
	//추상 메소드
	void run();
}
