package week02.sec06;

public class task01 {

	public static void main(String[] args) {
		//print를 사용하여 같은 줄에 1부터 10까지의 숫자를 인쇄하는 프로그램을 작성하세요.
		System.out.print("1,2,3,4,5,6,7,8,9,10\n\n");
		
		String a= "1,2,3,4,5,6,7,8,9,10";
		System.out.print(a);
		
	}

}
