package week13_2.sec01;

public interface Searchable {
	//추상 메소드
	void search(String url);
}
