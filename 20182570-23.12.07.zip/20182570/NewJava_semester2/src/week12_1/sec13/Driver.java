package week12_1.sec13;

public class Driver {
	public void drive(Vehicle vehicle) {
		vehicle.run();
	}
}
