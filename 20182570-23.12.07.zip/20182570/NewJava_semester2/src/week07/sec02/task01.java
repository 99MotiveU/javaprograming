package week07.sec02;

public class task01 {

	public static void main(String[] args) {
		// 구구단의 짝수만 출력하는 프로그램을 작성
		int i;
		int t;
		for(i=1; i<=9; i++) {
			for(t=1; t<=9; t++) {
				while(i%2==0) {
					System.out.println(i+" * "+t +" = " + i*t);
					continue;
				}
			}
		}
	}
}
