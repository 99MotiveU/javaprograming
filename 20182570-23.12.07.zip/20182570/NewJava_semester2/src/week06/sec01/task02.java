package week06.sec01;

import java.util.Scanner;

public class task02 {

	public static void main(String[] args) {
		// 반복 수를 입력 받아서 출력
		Scanner scanner = new Scanner(System.in);
		System.out.print("반복 수 입력(최대 100000000) : ");
		int i = scanner.nextInt();
		
		while(i<100000000) {
			
		}
		System.out.println("this is java");
	}
	

}
