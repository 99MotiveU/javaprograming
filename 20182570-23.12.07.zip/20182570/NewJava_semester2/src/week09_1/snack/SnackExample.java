package week09_1.snack;

public class SnackExample {

	public static void main(String[] args) {
		Snack s1 = new Snack();
		System.out.println("s1 변수가 snack 객체를 참조합니다.");
		
		Snack s2 = new Snack();
		System.out.println("s2 변수가 또다른 snack 객체를 참조합니다.");
	}

}
