package week10_1.sec01;

public class task01Ex {

	public static void main(String[] args) {
		
		task01 myCalc = new task01();
		//리턴값이 없는 poweron() 메소드 호출
		myCalc.powerOn();
		

		
		int result=(int) myCalc.mul(5, 6);
		System.out.println("result : " + result);
		
		//리턴값이 없는 powerOff() 메소드 호출
		myCalc.powerOff();

	}

}
