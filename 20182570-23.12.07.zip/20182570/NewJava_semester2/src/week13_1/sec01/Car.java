package week13_1.sec01;

public interface Car {
	public void model();
}
