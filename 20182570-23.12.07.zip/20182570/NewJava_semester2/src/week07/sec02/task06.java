package week07.sec02;

public class task06 {

	public static void main(String[] args) {
		//X^2-9X+14=0의 해를 구하고 구한 후에 멈추는 코드 작성

	}

}
