package week08;

public class task05 {

	public static void main(String[] args) {
		// "hello.java" 무자열에서 파일명은 hello와 확장자인 java를 분리
		String board = "hello,java";
		
		//문자열 분리
		String[] tokens = board.split(",");
		
		//인덱스별로 읽기
		System.out.println("파일명 : " + tokens[0]);
		System.out.println("확장자명 : " + tokens[1]);
	}

}
