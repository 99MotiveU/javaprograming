package week12_1.sec06;

public class A {
	protected String field;
	
	protected A() {
	}
	
	protected void method() {
	}
}
