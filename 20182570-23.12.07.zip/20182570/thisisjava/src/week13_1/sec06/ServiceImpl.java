package week13_1.sec06;

public class ServiceImpl implements Service {

}
