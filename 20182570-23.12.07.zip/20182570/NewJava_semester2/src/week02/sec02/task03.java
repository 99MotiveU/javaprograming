package week02.sec02;

public class task03 {

	public static void main(String[] args) {
		int x;
		x=4;
		int y;
		y=2;
		int result3 = x*y;
		System.out.println(result3);

	}

}
