package week12_1.sec01;

public class VeryImportantPerson extends Member {

}
