package week02.sec06;

public class task02 {

	public static void main(String[] args) {
		// 단리와 복리 계산 변수는 모두 소수 2째자리로 선언하고, 계산 결과가 정수, 소수 둘째자리까지 나오도록한다.
		int PV = 100000;
		double r = 0.02;
		int n = 3;
		double FV1 = PV*(1+r*n);
		double FV2 = PV*(1+r)*(1+r)*(1+r);
		//MathPOW((1+r),n);
		
		System.out.printf("원금이 10만원, 이자율이 2퍼센트, 기간은 3개월 일때 단리 이자와 원금을 합한 금액은 %10.2f\n원" + " 원 입니다.",FV1);
		System.out.printf("원금이 10만원, 이자율이 2퍼센트, 기간은 3개월 일때 복리 이자와 원금을 합한 금액은 %10.2f원" + " 원 입니다.",FV2 );
		
	}

}
