package week10_1.sec03;


public class task03Ex {

	public static void main(String[] args) {
		task03 myCal = new task03();
		
		int[] values = {1,2,3,4,5};
		int result1 = myCal.sum(values);
		System.out.println("result1 : " + result1);
		
		int result2 = myCal.minu(values);
		System.out.println("result2 : " + result2);
		
		int result3 = myCal.mul(values);
		System.out.println("result3 : " + result3);
		
		int result4 = myCal.div(values);
		System.out.println("result4 : " + result4);
	}

}
