package week02.sec01;

public class task04 {
	
	public static void main(String[] args) {
		System.out.println("나 자신을 위하자");
	}
}
