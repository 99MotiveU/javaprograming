package week13_2.sec05;

public class FlyHankook implements Airplane {
	@Override
	public void fly() {
		System.out.println("한국타이어를 장착한 비행기가 이륙합니다.");
	}
}
