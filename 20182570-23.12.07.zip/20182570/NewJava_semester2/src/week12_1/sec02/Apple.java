package week12_1.sec02;

public class Apple extends Fruit{
	@Override
	public void abandon() {
		count -= 1;
	}
	
	// final클래스 - 오버라이딩 x
}
