package week09_1.snack1;

public class SnackExample {

	public static void main(String[] args) {
		Snack mySnack = new Snack();
		
		System.out.println("종류 : " + mySnack.type);
		System.out.println("이름 : " + mySnack.name);
		System.out.println("개수 : " + mySnack.count);
		System.out.println("가격 : " + mySnack.price);


	}

}
