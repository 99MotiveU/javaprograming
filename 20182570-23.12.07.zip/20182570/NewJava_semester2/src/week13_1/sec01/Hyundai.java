package week13_1.sec01;

public class Hyundai implements Car {
	@Override
	public void model() {
		System.out.println("현대 자동차 입니다.");
	}
	
}
