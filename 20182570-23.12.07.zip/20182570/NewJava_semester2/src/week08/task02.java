package week08;

public class task02 {

	public static void main(String[] args) {
		// 위의 문제에서 성과 이름을 분리하라
		String name = "kim sung min";
		String rename = name.replace("kim","lee");
		String namesplit = "kim, sung min";
		String[] lname =namesplit.split(",");
		
		System.out.println(name);
		System.out.println(rename);
		System.out.print("성 : " + lname[0] + "    ");
		System.out.println("이름 : "+ lname[1]);
	}

}
