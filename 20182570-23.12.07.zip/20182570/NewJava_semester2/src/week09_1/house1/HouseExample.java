package week09_1.house1;

public class HouseExample {

	public static void main(String[] args) {
		House myHouse = new House();
		
		System.out.println("방 종류 : " + myHouse.name);
		System.out.println("방 개수 : " + myHouse.roomcount);
		System.out.println("화장실 수 : " + myHouse.toiletcount);
		System.out.println("마당 유무 : " + myHouse.ground);


	}

}
