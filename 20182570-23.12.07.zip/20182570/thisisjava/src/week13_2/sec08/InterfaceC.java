package week13_2.sec08;

public interface InterfaceC extends InterfaceB {
	void methodC();
}
