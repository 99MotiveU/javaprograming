package week13_1.sec02;

public class Orange implements Fruit {
	@Override
	public void fruit() {
		System.out.println("오렌지 입니다.");
	}
}
