package week13_2.sec05;

public interface Tire {
	//추상 메소드
	void roll();
}
