package week11.sec03;
import week11.sec03.*;
public class C {
	A a1 = new A(true);
}
