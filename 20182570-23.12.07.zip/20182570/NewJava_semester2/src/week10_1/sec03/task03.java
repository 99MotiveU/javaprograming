package week10_1.sec03;

public class task03 {
	//배열로 값을 5개 입력 받아, 사칙연산 계산
	int sum(int...values) {
		int sum =0;
		for(int i = 0; i<values.length; i++) {
			sum+=values[i];
		}
		return sum;
	}
	
	int minu(int...values) {
		int minu=0;
		for(int i1 = 0; i1<values.length; i1++) {
			minu-=values[i1];
		}
		return minu;
	}
	
	int mul(int...values) {
		int mul =1;
		for(int i2 = 0; i2<values.length; i2++) {
			mul*=values[i2];
		}
		return mul;
	}
	
	int div(int...values) {
		int div = 1;
		for(int i3 = 0; i3<values.length; i3++) {
			div/=values[i3];
		}
		return div;
	}
}
