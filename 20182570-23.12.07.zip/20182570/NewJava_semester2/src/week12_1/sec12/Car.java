package week12_1.sec12;

public class Car {
	public Tire tire;
	
	public void run() {
		tire.roll();
	}
}
