package week06.sec02;

public class task02 {

	public static void main(String[] args) {
		// Do-while 문을 이용하여 수를 입력 받아서 총합과 평균을 구하시오

	}

}
