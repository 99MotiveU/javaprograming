package week08;

public class task01 {

	public static void main(String[] args) {
		// "kim sung min"이라는 문자열을 생성하고 성을 lee로 변경하여 출력
		String name = "kim sung min";
		String rename = name.replace("kim","lee");
		
		System.out.println(name);
		System.out.println(rename);
	}

}
