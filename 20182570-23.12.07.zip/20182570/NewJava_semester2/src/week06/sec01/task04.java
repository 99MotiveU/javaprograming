package week06.sec01;

import java.util.Scanner;

public class task04 {

	public static void main(String[] args) {
		// 원하는 구구단을 입력 받아서 출력
		Scanner scan =new Scanner(System.in);
		System.out.print("구구단 단수를 입력하세요 ");
		int t = scan.nextInt();
		int i=1;
		System.out.println();
		System.out.println("  "+t+"단");
		while(t<=9) {
			while(i<9) {
				i++;
				System.out.println(t+"*"+i+"="+t*i);
		}

			}
	}

}
