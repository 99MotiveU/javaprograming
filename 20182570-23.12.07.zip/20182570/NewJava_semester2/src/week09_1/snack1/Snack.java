package week09_1.snack1;

public class Snack {
	String type = "비스킷";
	String name = "에이스";
	int count = 20;
	int price = 2500;
}
