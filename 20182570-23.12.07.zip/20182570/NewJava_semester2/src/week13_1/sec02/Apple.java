package week13_1.sec02;

public class Apple implements Fruit{
	@Override
	public void fruit() {
		System.out.println("사과 입니다.");
	}
}
