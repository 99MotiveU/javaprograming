package week09_1.pet1;

public class Pet {
	String type = "말티즈";
	String name = "유마음";
	int age = 8;
	int weight = 3;
	int height = 30;
}
