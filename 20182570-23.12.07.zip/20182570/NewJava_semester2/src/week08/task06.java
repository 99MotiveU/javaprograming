package week08;

public class task06 {

	public static void main(String[] args) {
		// "62.78.96.54.46"의 문자열을 split을 사용하여 배열로 받아서 문자를 integer.parseint()메서드 정수로 바꾸고 총합과 평균을 구하시오, 길이는 length()메서드 사용[반보문 사용]

	}

}
