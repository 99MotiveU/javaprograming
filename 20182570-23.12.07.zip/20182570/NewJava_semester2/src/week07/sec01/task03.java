package week07.sec01;

import java.util.Scanner;

public class task03 {
	public static void main(String[] args) {
		// 식당 메뉴 주문 코드를 무한 반복을 하고 끝날 조건을 넣어서 끝을 내는 프로그램 작성
		Scanner scanner = new Scanner(System.in);
		int i=0;
		while(true) {
			System.out.println("메뉴를 선택하세요");
			System.out.println("1.돈까스  2.파스타  3.김치찌개  4.주문x");
			int a = scanner.nextInt();

			if(a==4) {
				System.out.println("지금까지 주문하신 메뉴의 개수 : "+i);
				break;
			}
			++i;
		}
	}

}
