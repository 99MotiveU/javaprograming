package week09_2.sec03;

public class House {
	String type;
	String wp;
	int toilet;
	String ground;
	
	House(String type){
		this(type,"Y",2,"N");
	}
	House(String type, String wp){
		this(type,wp,2,"N");
	}
	House(String type, String wp, int toilet){
		this(type,wp,toilet,"N");
	}
	House(String type, String wp, int toilet, String ground){
		this.type = type;
		this.wp = wp;
		this.toilet = toilet;
		this.ground = ground;
	}
}
