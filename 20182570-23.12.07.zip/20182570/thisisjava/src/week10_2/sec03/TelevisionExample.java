package week10_2.sec03;

public class TelevisionExample {

	public static void main(String[] args) {
		System.out.println(Television.info);

	}

}
