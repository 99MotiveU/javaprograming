package week11.sec01.kumho;

public class Tire {

}
