package week12_1.sec08_2;
import week12_1.sec08_1.A;
public class D extends A{
	public D() {
		super();
	}
	public void method1() {
		this.field = "value";
		this.method();
	}
	public void method2() {
		// A a = new A(); //x
		// a,field = "value"; //x
		// a.method(); //x
	}
}
