package week13_2.sec03;

public class E extends C{

}
