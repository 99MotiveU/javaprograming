package week09_1.person;

public class PersonExample {

	public static void main(String[] args) {
		Person p1 = new Person();
		System.out.println("p1 변수가 Student 객체를 참조합니다.");
		
		Person p2 = new Person();
		System.out.println("p2 변수가 또 다른 Student 객체를 참조합니다.");
	}

}
