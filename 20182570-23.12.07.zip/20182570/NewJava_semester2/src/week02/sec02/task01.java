package week02.sec02;

public class task01 {

	public static void main(String[] args) {
		int x;
		x=4;
		int y;
		y=2;
		int result1 = x+y;
		System.out.println(result1);

	}

}
