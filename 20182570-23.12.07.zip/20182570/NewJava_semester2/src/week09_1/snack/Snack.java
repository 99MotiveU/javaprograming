package week09_1.snack;

public class Snack {

}
