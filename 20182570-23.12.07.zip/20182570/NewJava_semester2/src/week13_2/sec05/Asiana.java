package week13_2.sec05;

public class Asiana {
	Airplane fly1 = new FlyHankook();
	Airplane fly2 = new FlyKumho();
	
	void fly() {
	fly1.fly();
	fly2.fly();
	}
}
