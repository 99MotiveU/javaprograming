package week04;

import java.util.Scanner;

public class task03 {

	public static void main(String[] args) {
		// 가게 주문 메뉴를 보여주고 선택한 메뉴의 개수를 입력 받아서 계산하여 출력하는 프로그램 작성
		Scanner scan = new Scanner(System.in);
		System.out.println("메뉴 : 자장면(1) , 자장밥(2), 짬뽕(3), 짬뽕밥(4)");
		int menu=scan.nextInt();
		System.out.println("갯수 입력");
	
		int num=scan.nextInt();
		int s = num*6000;
		int t = num*6500;
		int u = num*7000;
		int v = num*7500;
		
		switch(menu) {
		case 1 ->  {
			System.out.println("자장면 " + num +"개 + 주문하여" + s + "원 입니다." );

		}
		case 2 -> {
			System.out.println("자장밥 " + num +"개 주문하여" + t + "원 입니다.");
			
		}
		case 3 -> {
			System.out.println("짬뽕 " + num + "개 주문하여" + u + "원 입니다.");
		
		}
		default -> {
			System.out.println("짬뽕밥 " + num + "개 주문하여" + v + "원 입니다.");
		
		}
		
		};
		scan.close();
	}
	
}
