package week12_1.sec07;
import week12_1.sec06.A;
public class D extends A{
	public D() {
		//A()생성자 호출
		super(); //o
	}
	//메소드 선언
	public void method1() {
		//A필드값 변경
		this.field = "value"; //o
		//A메도스 호출
		this.method(); //o
	}
	//메소드 선언
	public void method2() {
		// a a = new A(); //x
		// a.field = "value"; //x
		// a.method(); //x
		//직접 객체생성 안됨
	}
	// sec4,5,6,7 필기시험 가능성
	
}
