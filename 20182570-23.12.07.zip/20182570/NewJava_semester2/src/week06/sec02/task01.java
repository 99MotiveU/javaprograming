package week06.sec02;

public class task01 {

	public static void main(String[] args) {
		// Do-while문을 이용하여 두수를 입력 받고 사칙연산 중 선택하여 계산하는 프로그램 작성
		
	}

}
