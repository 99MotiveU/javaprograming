package week09_2.sec05;

public class BreadExample {

	public static void main(String[] args) {
		Bread bread1 = new Bread("바게트");
		System.out.println("bread1.type : " + bread1.type);
		System.out.println();
		
		Bread bread2 = new Bread("바게트",1);
		System.out.println("bread2.type : " + bread2.type);
		System.out.println("bread2.count : " + bread2.count);
		System.out.println();
		
		Bread bread3 = new Bread("바게트",1,321);
		System.out.println("bread3.type : " + bread3.type);
		System.out.println("braed3.count : " + bread3.count);
		System.out.println("bread3 : " + bread3.cal);
		System.out.println();
		
		Bread bread4 = new Bread("바게트",1,321,3000);
		System.out.println("bread4.type : " + bread4.type);
		System.out.println("braed4.count : " + bread4.count);
		System.out.println("bread4 : " + bread4.cal);
		System.out.println("bread4 : " + bread4.price);

	}

}
