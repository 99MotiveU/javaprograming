package week02.sec02;

public class task02 {

	public static void main(String[] args) {
		int x;
		x=4;
		int y;
		y=2;
		int result2 = x-y;
		System.out.println(result2);
		

	}

}
