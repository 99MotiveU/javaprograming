package week13_2.sec06;

public class Airplane implements Vehicle{
	@Override
	public void run() {
		System.out.println("비행기가 이륙합니다.");
	}
}
