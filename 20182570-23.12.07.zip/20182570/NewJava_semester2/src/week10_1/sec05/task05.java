package week10_1.sec05;

public class task05 {
	//메소드 오버 리딩으로 직각 삼각형, 정삼각형 둘레 구하기
	int tri(int a, int b, int c) {
		return a+b+c;
	}
	
	int tri(int a) {
		return a+a+a;
	}
}
