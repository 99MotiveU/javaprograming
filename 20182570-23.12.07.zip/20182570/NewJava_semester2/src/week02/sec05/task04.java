package week02.sec05;

public class task04 {

	public static void main(String[] args) {
		double doubleValue1 = 10;
		double doubleValue2 = 15;
		double result = doubleValue1 + doubleValue2;
		int intValue = (int) result;
		
		System.out.println(intValue);

	}

}
