package week13_2.sec03;

public class C implements A {

}
