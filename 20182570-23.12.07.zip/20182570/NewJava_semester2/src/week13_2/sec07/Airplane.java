package week13_2.sec07;

public class Airplane implements Vehicle {
	@Override
	public void run() {
		System.out.println("비행기가 이륙합니다.");
	}
	public void checkFare() {
		System.out.println("운항 비용을 체크합니다.");
	}
}
