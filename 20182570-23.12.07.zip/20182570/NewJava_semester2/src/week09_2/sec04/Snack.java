package week09_2.sec04;

public class Snack {
	String type;
	String name;
	int count;
	int price;
	
	Snack(String type){
		this(type,"아이비",1,3000);
	}
	Snack(String type, String name){
		this(type,name,1,3000);
	}
	Snack(String type, String name, int count){
		this(type,name,count,3000);
	}
	Snack(String type, String name, int count, int price){
		this.type = type;
		this.name = name;
		this.count = count;
		this.price = price;
	}
}
