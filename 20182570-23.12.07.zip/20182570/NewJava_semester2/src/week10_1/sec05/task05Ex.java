package week10_1.sec05;


public class task05Ex {

	public static void main(String[] args) {
		task05 mytri = new task05();
		
		
		int result1 = mytri.tri(3,4,5);
		
		int result2 = mytri.tri(10, 10,10);
		
		System.out.println("직각 삼각형의 둘레 = " + result1);
		System.out.println("정삼각형의 둘레 = " + result2);

	}

}
