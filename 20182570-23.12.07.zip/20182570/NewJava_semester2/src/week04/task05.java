package week04;

import java.util.Scanner;

public class task05 {

	public static void main(String[] args) {
		// 점수를 입력 받아서 점수 구간별로  A+,A,B+,B,C+,C,D+,D,F의 성적을 주는 코드를 작성
		Scanner scan = new Scanner(System.in);
		System.out.println("점수를 입력하세요(0~100)");
		int score=scan.nextInt();
		
		switch(score) {
			case 100,99,98,97,96,95 -> {
				System.out.println("A+ 등급입니다.");
			}
			case 94,93,92,91,90 -> {
				System.out.println("A 등급입니다.");
			}
			case 89,88,87,86,85 -> {
				System.out.println("B+ 등급입니다.");
			}
			case 84,83,82,81,80 -> {
				System.out.println("B 등급입니다.");
			}
			case 79,78,77,76,75 -> {
				System.out.println("C+ 등급입니다.");
			}
			case 74,73,72,71,70 -> {
				System.out.println("C 등급입니다.");
			}
			case 69,68,67,66,65 -> {
				System.out.println("D+ 등급입니다.");
			}
			case 64,63,62,61,60 -> {
				System.out.println("D 등급입니다.");
			}
			default -> {
				System.out.println("F 등급 입니다");

			}
		
		};
		scan.close();
	}

}
