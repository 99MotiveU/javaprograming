package week12_1.sec07_2;

import week12_1.sec07_1.A;

public class C {
	public void mthod() {
		//A a = new A(); //x
		//a.field = "value";//x
		//a.method(); //x
	}
}
