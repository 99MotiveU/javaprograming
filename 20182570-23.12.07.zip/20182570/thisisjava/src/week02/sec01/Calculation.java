package week02.sec01;

public class Calculation {

	public static void main(String[] args) {
		int x;
		x=1;
		int y =2;
		int result = x+y;
		System.out.println(result);

	}

}
