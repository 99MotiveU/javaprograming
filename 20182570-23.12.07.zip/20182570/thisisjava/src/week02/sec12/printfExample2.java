package week02.sec12;

public class printfExample2 {

	public static void main(String[] args) {
		System.out.printf("자리수 미지정 :%d%n",1);
		System.out.printf("자리수 미지정 :%d%n",10);
		System.out.printf("자리수 미지정 :%d%n",100);
		System.out.printf("자리수 미지정 :%d%n",1000);
		
		System.out.printf("자리수 지정 : %4d%n",1);
		System.out.printf("자리수 지정 : %4d%n",10);
		System.out.printf("자리수 지정 : %4d%n",100);
		System.out.printf("자리수 지정 : %4d%n",1000);
		System.out.printf("자리수 지정 : %-4d%n",1);

		System.out.printf("자리수 지정('0'사용):%04d%n",1);
		System.out.printf("자리수 지정('0'사용):%04d%n",10);
		System.out.printf("자리수 지정('0'사용):%04d%n",100);
		System.out.printf("자리수 지정('0'사용):%04d%n%n",1000);
		System.out.printf("자리수 지정('0'사용):%040d%n",1);
	}

}
