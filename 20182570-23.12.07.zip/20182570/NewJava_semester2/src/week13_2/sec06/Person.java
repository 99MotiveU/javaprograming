package week13_2.sec06;

public class Person implements Vehicle{
	@Override
	public void run() {
		System.out.println("두다리로 달립니다.");
	}
}
