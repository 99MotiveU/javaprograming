package week08.sec01;

public class TypeSting {

	public static void main(String[] args) {
		String name; //String 타입 변수 name 선언
		name = "홍길동";//name 변수에 문자열 대입
		String hobby = "여행"; //String 타입 변수 hobby를 선언하고 문자열 대입
		
		//문자열 비교 = 문자열 리터럴이 동일하다면 String 객체를 공유
		//new 연산자(객체 생성 연산자)로 직접 String 객체를 생성/대입 가능
		
		//Stringname1=new String("홍길동");
		//Stringname2=new String("홍길동");
		// 각각의 홍길동을 가져옴 new가 붙으면 결과가 서로 달라짐
		//Stringname1 ="홍길동";
		//Stringname2 ="홍길동";
		//Stringname3 = new String("홍길동");
		//name1==name2 //결과: true
		//name1==name3 //결과: false
		
		//내부문자열 만을 비교 할 경우엔 String 객체의 equals()메소드 이용
		//boolean result=str1.equals(str2);
		//boolean result=!str1.equals(str2);
	}

}
