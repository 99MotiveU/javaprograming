package week09_2.sec05;

public class Bread {
	String type;
	int count;
	int cal;
	int price;
	
	Bread(String type){
		this(type,5,568,3000);
	}
	Bread(String type, int count){
		this(type,count,568,3000);
	}
	Bread(String type, int count, int cal){
		this(type,count,cal,3000);
	}
	Bread(String type, int count, int cal, int price){
		this.type = type;
		this.count = count;
		this.cal = cal;
		this.price = price;
	}
}
