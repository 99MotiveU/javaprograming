package week12_1.sec01;

public class BusanAir extends AirPlane {
	public void speedUP() {
		//speed +== 100;
	}
}
