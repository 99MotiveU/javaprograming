package week04;

import java.util.Scanner;

public class task01 {
	public static void main(String[] args) {
		// 1에서부터 5까지 문자열을 입력 받아서 결정한 벌칙 출력하는 코드 작성("1"과 "일"둘다 입력해도 동일 결과
		Scanner scanner = new Scanner(System.in);
		System.out.print("숫자 입력 : ");
		String strX = scanner.next();
	
		
		switch(strX) {
		case "1","일" :				
			System.out.println("엉덩이로 이름쓰기");
			break;
		case "2","이" :
			System.out.println("딱밤맞기");
			break;
		case "3","삼" :
			System.out.println("뺨 맞기");
			break;
		case "4","사" :
			System.out.println("명치 한대");
			break;
		case "5","오" : 
			System.out.println("발차기");
			break;
		default:
			System.out.println("1~5의 숫자를 입력하세요.");
		}
		scanner.close();
	}
}