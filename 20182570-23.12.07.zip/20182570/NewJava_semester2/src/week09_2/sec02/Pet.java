package week09_2.sec02;

public class Pet {
	String type;
	String name;
	int age;
	int weight;
	int height;

	Pet(String type){
		this(type,"유마음",8,3,40);
	}
	Pet(String type, String name){
		this(type, name,8,3,40);
	}
	Pet(String type, String name, int age){
		this(type, name, age, 3, 40);
	}
	Pet(String type, String name, int age, int weight){
		this(type, name, age, weight, 40);
	}
	Pet(String type, String name, int age, int weight, int height){
		this.type = type;
		this.name = name;
		this.age = age;
		this.weight =weight;
		this.height = height;
	}
}
