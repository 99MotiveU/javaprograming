package week02.sec01;

public class task01 {

	public static void main(String[] args) {
		System.out.println("hello, everyone");
		
		
		
		

	}

}
