package week09_1.sec03;

public class Car {
	//필드 선언
	String model;
	boolean start;
	int speed;
}
