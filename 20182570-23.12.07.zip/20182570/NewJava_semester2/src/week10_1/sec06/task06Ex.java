package week10_1.sec06;


public class task06Ex {

	public static void main(String[] args) {
		task06 myCal = new task06();
		int[] values = {1,2,3,4,5};
		int result1 = myCal.sum(values);
		System.out.println("result1 : " + result1);
		int result2 = (int) myCal.ave(values);
		System.out.println("result2 : " + result2);
	}

}
