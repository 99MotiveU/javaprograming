package week12_1.sec13;

public class Vehicle {
	public void run() {
		System.out.println("차량이 달립니다.");
	}
}
