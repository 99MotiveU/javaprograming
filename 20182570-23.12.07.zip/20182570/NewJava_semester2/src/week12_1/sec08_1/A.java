package week12_1.sec08_1;

public class A {
	protected String field;
	
	protected A() {
	}
	protected void method() {}
}
