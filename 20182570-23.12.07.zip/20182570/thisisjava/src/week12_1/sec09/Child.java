package week12_1.sec09;

public class Child extends Parent {
	//메소드 오버라이딩
	@Override
	public void method2() {
		System.out.println("Child-mehtod2()");
	}
	public void method3() {
		System.out.println("child-method3()");
	}
}
