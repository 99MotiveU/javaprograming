package week09_2.sec03;

public class HouseExample {

	public static void main(String[] args) {
		House house1 = new House("그냥 집");
		System.out.println("house1.type : " + house1.type);
		System.out.println();
		
		House house2 = new House("그냥 집","N");
		System.out.println("house2.type : " + house2.type);
		System.out.println("house2.wp : " + house2.wp);
		System.out.println();
		
		House house3 = new House("그냥 집","N",2);
		System.out.println("house3.type : " + house3.type);
		System.out.println("house3.wp : " + house3.wp);
		System.out.println("house3.toilet : " + house3.toilet);
		System.out.println();
		
		House house4 = new House("그냥 집","N",2,"N");
		System.out.println("house4.type : " + house4.type);
		System.out.println("house4.wp : " + house4.wp);
		System.out.println("house4.toilet : " + house4.toilet);
		System.out.println("house4.ground : " + house4.ground);
		System.out.println();		
		
	}

}
