package week12_1.sec05;
import week12_1.sec04.*;
public class C {
	//메소드 선언
	public void method() {
		// A a = new A(); //x
		// a.field = "value"; //x
		// a.method(); //x
	}
}
