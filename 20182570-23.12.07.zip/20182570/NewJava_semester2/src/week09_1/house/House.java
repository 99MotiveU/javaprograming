package week09_1.house;

public class House {

}
