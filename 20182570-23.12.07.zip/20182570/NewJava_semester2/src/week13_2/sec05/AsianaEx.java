package week13_2.sec05;

public class AsianaEx {
	public static void main(String[]args) {
		Asiana myap = new Asiana();
		
		myap.fly();
		
		myap.fly1 = new FlyHankook();
		myap.fly2 = new FlyKumho();
		
		myap.fly();
	}
}
