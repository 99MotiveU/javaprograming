package week13_2.sec02;

public interface InterfaceC extends InterfaceA, InterfaceB {
	void methodC();
}
