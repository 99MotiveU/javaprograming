package week12_1.sec12;

public class KumhoTire extends Tire {
	@Override
	public void roll() {
		System.out.println("금호 타이어가 회전합니다.");
	}
}
