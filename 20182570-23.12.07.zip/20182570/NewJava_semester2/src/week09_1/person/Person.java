package week09_1.person;

public class Person {

}
