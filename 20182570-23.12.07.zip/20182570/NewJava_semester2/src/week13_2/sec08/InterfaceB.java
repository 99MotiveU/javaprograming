package week13_2.sec08;

public non-sealed interface InterfaceB extends InterfaceA{
	void methodB();
}
