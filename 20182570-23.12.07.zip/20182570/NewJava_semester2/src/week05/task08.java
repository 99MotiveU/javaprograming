package week05;

public class task08 {

	public static void main(String[] args) {
		// 1에서 20까지의 수에 4를 더한 수를 출력하는 프로그램
		int i =0;
		for(i=1;i<=20;i++) {
			int s=i+4;
			System.out.println("1애소 20까지의 수에 4를 더한 수들 "+s);
		}
	}

}
