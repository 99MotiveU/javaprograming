package week05;

public class task13 {

	public static void main(String[] args) {
		// 입력 값1과 입력 값2사이의 합과 곱을 선택하여 계산하는 프로그램

	}

}
