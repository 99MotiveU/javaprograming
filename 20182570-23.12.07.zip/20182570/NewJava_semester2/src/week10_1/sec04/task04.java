package week10_1.sec04;

public class task04 {
	//음식점에서의 음식 소진

	int food;
	
	void setfood(int gas) {
		this.food = gas;
		
	}

	boolean isLeftfood() {
		if(food==0) {
			System.out.println("음식이 없습니다.");
			return false; 
		}
		System.out.println("음식이 있습니다.");
		return true; 
	}

	void eat() {
		while(true) {
			if(food>0) {
				System.out.println("먹습니다.(Food 잔량 : "  + food + ")");
				food -=1;
			}else {
				System.out.println("그만 먹습니다. 살찝니다. 음식도 더 없습니다.(Food 잔량 : " + food + ")");
				return;
			}
		}
	}

}
