package weel09_2.sec01;

public class Car {
	//생성자 선언
	Car(String mod, String col, int maxSp){
	}
}
