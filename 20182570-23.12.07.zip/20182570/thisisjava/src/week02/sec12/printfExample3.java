package week02.sec12;

public class printfExample3 {

	public static void main(String[] args) {
		int num1 =1;
		double num2=12.3456789;
		
		System.out.printf("num1:%d%n",num1);
		System.out.printf("num2:%f%n",num2);
		System.out.printf("num2(소수점 첫째 자리까지) :%.1f%n",num2);
		System.out.printf("num2(소수점 둘째 자리까지) :%.2f%n",num2);
		System.out.printf("num2(소수점 셋째 자리까지) :%.3f%n",num2);
		System.out.printf("num2(소수점 첫째 자리까지) :%.10.1f%n",num2);
		System.out.printf("num2(소수점 둘째 자리까지) :%.10.2f%n",num2);
		System.out.printf("num2(소수점 셋째 자리까지) :%.10.3f%n",num2);
	}

}
