package week02.sec07;

import java.util.Scanner;

public class task03 {

	public static void main(String[] args) {
		// 삼각형 사각형 넓이 입력 받아 계산
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("삼각형의 밑변 길이 입력");
		String strX = scanner.nextLine();
		int x = Integer.parseInt(strX);
		
		System.out.print("삼각형의 높이 입력");
		String strH = scanner.nextLine();
		int h = Integer.parseInt(strH);
		
		double s1 = (x*h)/2;
		System.out.println("삼각형의 넓이는 : " + s1);
		
		
		System.out.print("사각형의 가로 길이 입력");
		String strY = scanner.nextLine();
		int y = Integer.parseInt(strY);
		
		System.out.print("사각형의 세로 입력");
		String strI = scanner.nextLine();
		int i = Integer.parseInt(strI);
		
		double s2 = (y*i);
		System.out.println("사각형의 넓이는 : " + s2);
		
	}

}
