package week02.sec13;

import java.util.Scanner;

public class ScannerEx {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("나이를 입력해 주세요.");
		int age = scanner.nextInt();//정수형만 받는 메소드
		
		System.out.printf("내 나이는 %d세 입니다.",age);

	}//main

}//class
