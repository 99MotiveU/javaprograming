package week04;

import java.util.Scanner;

public class task02 {

	public static void main(String[] args) {
		// 달을 입력하면 31일 인지, 아니면 30일인지 29일 인지 출력하는 코드 작성 --> 반대로 일을 입력하면 월을 출력
		Scanner scan = new Scanner(System.in);
		System.out.println("일을 입력하세요:");
		int days=scan.nextInt();
		
		int day = switch(days) {
		case 31 ->  {
			System.out.println("31일인 달은 1,3,5,7,8,10,12입니다.");
			yield 31;
		}
		case 30 -> {
			System.out.println("30일인 달은 4,6,9,11월입니다.");
			yield 30;
		}
		case 29 -> {
			System.out.println("29일인 달은 2월 입니다.");
			yield 29;
		}
		default -> {
			System.out.println("존재하지 않는 달입니다.");
			yield 0;
		}
		
		};
		scan.close();
	}
}
