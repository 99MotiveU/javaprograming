package week02.sec01;

public class task05 {

	public static void main(String[] args) {
		System.out.println("나는 모든 것을 할 수 있다");

	}

}
